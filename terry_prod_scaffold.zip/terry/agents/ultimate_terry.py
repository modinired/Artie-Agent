from __future__ import annotations
import asyncio
from terry.common.logging import logger
from terry.knowledge.knowledge_brain import KnowledgeBrain
from terry.common.config import settings

class Terry:
    def __init__(self) -> None:
        self.kb = KnowledgeBrain(settings.api_keys)
        # persona modes can be toggled via config later

    async def handle_chat(self, message: str, include_knowledge: bool, use_persona: bool):
        # Simple deterministic response with optional knowledge ping to avoid simulations
        resp = {"message": message}
        if include_knowledge:
            # perform a lightweight head request to ensure connectivity to a real source
            try:
                ping = await self.kb.ping_fred()
                resp["knowledge_ok"] = ping
            except Exception as e:
                resp["knowledge_ok"] = {"ok": False, "err": str(e)}
        return {"response": f"Terry received: {message}", "meta": resp}

    async def macro_snapshot(self, series_ids: list[str]):
        data = {}
        for sid in series_ids:
            data[sid] = await self.kb.fetch_fred_series(sid)
        return {"series": data}

    async def handle_task(self, task: str):
        # In production, route via Automation Matrix. Here we call KnowledgeBrain or other adapters.
        if task.lower().startswith("macro"):
            return await self.macro_snapshot(["FEDFUNDS","CPIAUCSL"])
        return {"status":"accepted","task":task}

    async def earnings_digest(self, ticker: str):
        from terry.knowledge.knowledge_brain import earnings_digest
        return await earnings_digest(ticker)
