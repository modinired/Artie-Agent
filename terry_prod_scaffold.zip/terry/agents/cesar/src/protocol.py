from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass
class Task:
    description: str

@dataclass
class Result:
    ok: bool
    data: Any

async def cycle(task: Task, ctx: dict) -> Result:
    # Hook up full loop here; returning minimal structure for now with real side-effects happening in agents
    return Result(ok=True, data={"task": task.description})
