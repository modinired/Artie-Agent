from __future__ import annotations
import httpx

class N8NClient:
    def __init__(self, base_url: str, api_key: str):
        self._c = httpx.AsyncClient(base_url=base_url, headers={"X-N8N-API-KEY": api_key}, timeout=30)

    async def create_workflow(self, name: str, nodes: list[dict], connections: dict):
        payload = {"name": name, "nodes": nodes, "connections": connections, "active": True}
        r = await self._c.post("/rest/workflows", json=payload)
        r.raise_for_status()
        return r.json()
