from __future__ import annotations
from .config import settings

class Guardian:
    def __init__(self):
        self.allowed_domains = set([d.strip() for d in settings.allowed_domains if d])

    async def ensure_capability(self, cap: str):
        # placeholder for fine-grained capability checks; extend with policy file
        return True

    def allow_domain(self, host: str) -> bool:
        return host in self.allowed_domains

guardian = Guardian()
