from __future__ import annotations
import os, time, jwt
from typing import List, Optional, Dict, Any
from fastapi import HTTPException, Header

JWT_SECRET = os.getenv("TERRY_JWT_SECRET", "change-me-" + os.urandom(8).hex())
JWT_AUDIENCE = "terry-users"
JWT_ISSUER = "terry-app"
JWT_ALGO = "HS256"
TOKEN_TTL = int(os.getenv("TERRY_JWT_TTL","28800"))  # 8h

# Simple in-memory user store (backed by env for demo). Replace with DB later.
# Format: TERRY_USERS='[{"username":"admin","roles":["admin","analyst"]}]'
def _users() -> list[dict]:
    import json
    raw = os.getenv("TERRY_USERS","[]")
    try:
        return json.loads(raw)
    except Exception:
        return []

def issue_token(sub: str, roles: List[str]) -> str:
    now = int(time.time())
    payload = {
        "sub": sub,
        "aud": JWT_AUDIENCE,
        "iss": JWT_ISSUER,
        "iat": now,
        "exp": now + TOKEN_TTL,
        "roles": roles,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO], audience=JWT_AUDIENCE, issuer=JWT_ISSUER)
    except jwt.PyJWTError as e:
        raise HTTPException(status_code=401, detail=f"Invalid token: {e}")

async def require_auth(authorization: Optional[str] = Header(default=None)) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, detail="Missing bearer token")
    token = authorization.split(" ",1)[1].strip()
    return decode_token(token)

def require_roles(*needed: str):
    async def checker(authorization: Optional[str] = Header(default=None)) -> dict:
        claims = await require_auth(authorization)
        roles = set(claims.get("roles", []))
        if not set(needed).issubset(roles):
            raise HTTPException(403, detail="Insufficient role")
        return claims
    return checker

def validate_user(username: str) -> dict | None:
    for u in _users():
        if u.get("username") == username:
            return u
    return None
