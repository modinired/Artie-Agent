from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Any, AsyncIterator

@dataclass
class Event:
    topic: str
    payload: dict

class EventBus:
    def __init__(self) -> None:
        self._q: asyncio.Queue[Event] = asyncio.Queue()

    async def publish(self, e: Event) -> None:
        await self._q.put(e)

    async def subscribe(self) -> AsyncIterator[Event]:
        while True:
            e = await self._q.get()
            yield e

bus = EventBus()
