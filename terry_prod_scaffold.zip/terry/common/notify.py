from __future__ import annotations
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
import os

def slack_client() -> WebClient | None:
    token = os.getenv("SLACK_BOT_TOKEN")
    if not token:
        return None
    return WebClient(token=token)

def notify_text(text: str, channel: str | None = None) -> dict:
    client = slack_client()
    if client is None:
        return {"ok": False, "error": "SLACK_BOT_TOKEN not set"}
    channel = channel or os.getenv("SLACK_CHANNEL", "")
    try:
        resp = client.chat_postMessage(channel=channel, text=text)
        return {"ok": True, "ts": resp["ts"]}
    except SlackApiError as e:
        return {"ok": False, "error": str(e)}
