from __future__ import annotations
from pydantic import BaseModel, Field
import os

class APIKeys(BaseModel):
    fred: str | None = Field(default=None, description="FRED API key")
    n8n: str | None = Field(default=None, description="n8n API key")

class Settings(BaseModel):
    postgres_dsn: str = Field(default_factory=lambda: os.getenv("POSTGRES_DSN","postgresql://user:password@localhost:5432/automation_matrix"))
    ollama_host: str = Field(default_factory=lambda: os.getenv("OLLAMA_HOST","http://localhost:11434"))
    openrouter_key: str | None = Field(default_factory=lambda: os.getenv("OPENROUTER_API_KEY"))
    gemini_key: str | None = Field(default_factory=lambda: os.getenv("GEMINI_API_KEY"))
    api_keys: APIKeys = Field(default_factory=lambda: APIKeys(
        fred=os.getenv("FRED_API_KEY"),
        n8n=os.getenv("N8N_API_KEY"),
    ))
    n8n_base_url: str = Field(default_factory=lambda: os.getenv("N8N_BASE_URL","http://localhost:5678"))
    # security/capabilities
    allowed_domains: list[str] = Field(default_factory=lambda: os.getenv("ALLOWED_DOMAINS","api.stlouisfed.org,api.sec.gov").split(","))

    def printable(self) -> dict:
        d = self.model_dump()
        # redact secrets
        if d.get("openrouter_key"):
            d["openrouter_key"] = "***"
        if d.get("gemini_key"):
            d["gemini_key"] = "***"
        if d.get("api_keys",{}).get("fred"):
            d["api_keys"]["fred"] = "***"
        if d.get("api_keys",{}).get("n8n"):
            d["api_keys"]["n8n"] = "***"
        return d

settings = Settings()
