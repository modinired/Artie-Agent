from __future__ import annotations
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from loguru import logger
import os, time
from terry.common.config import settings
from terry.knowledge.knowledge_brain import KnowledgeBrain
from terry.automation.matrix import AutomationMatrix

_scheduler: BackgroundScheduler | None = None

def start_scheduler():
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = BackgroundScheduler(timezone="UTC")
    _scheduler.start()

    # Knowledge refresh (FRED ping as a placeholder for complete ingestion job)
    kb = KnowledgeBrain(settings.api_keys)
    _scheduler.add_job(
        lambda: _safe_run(lambda: kb_fetch_macro(kb)),
        trigger=IntervalTrigger(minutes=30),
        id="kb-refresh",
        replace_existing=True,
        max_instances=1,
    )

    # Automation Matrix: refresh API keys and reload descriptors
    am = AutomationMatrix()
    _scheduler.add_job(
        lambda: _safe_run(lambda: am.refresh_credentials()),
        trigger=IntervalTrigger(minutes=10),
        id="matrix-refresh-keys",
        replace_existing=True,
        max_instances=1,
    )
    _scheduler.add_job(
        lambda: _safe_run(lambda: am.reload_descriptors()),
        trigger=IntervalTrigger(minutes=15),
        id="matrix-reload-descriptors",
        replace_existing=True,
        max_instances=1,
    )

    _schedule_workflow_index(_scheduler)
    logger.info("Background scheduler started")
    return _scheduler

def _safe_run(fn):
    try:
        fn()
    except Exception as e:
        logger.exception(f"Scheduled job error: {e}")

def kb_fetch_macro(kb: KnowledgeBrain):
    # Pull a tiny set to keep cache warm and verify live pipelines
    import asyncio
    asyncio.run(kb.fetch_fred_series("FEDFUNDS"))
    asyncio.run(kb.fetch_fred_series("CPIAUCSL"))
    logger.info("KnowledgeBrain macro warmup done")


def _index_workflows_from_csv():
    from terry.automation.matrix import AutomationMatrix
    from terry.knowledge.knowledge_brain import index_document_fallback
    am = AutomationMatrix()
    docs = []
    for row in am._workflows:
        doc_id = f"wf::{row.get('name','unnamed')}"
        text = (row.get('description') or row.get('name') or "").strip()
        meta = {"workflow": row}
        if text:
            # index one by one to avoid large batches in fallback
            import asyncio
            asyncio.run(index_document_fallback(doc_id, text, meta))
    logger.info("Indexed workflows into RAG")

# schedule it daily
def _schedule_workflow_index(_scheduler):
    _scheduler.add_job(
        lambda: _safe_run(_index_workflows_from_csv),
        trigger=IntervalTrigger(hours=24),
        id="index-workflows",
        replace_existing=True,
        max_instances=1,
    )

# call from start_scheduler
