from __future__ import annotations
from loguru import logger

logger.add("terry.log", rotation="10 MB", retention="7 days", enqueue=True)
