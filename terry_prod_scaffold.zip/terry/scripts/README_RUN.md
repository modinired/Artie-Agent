# Run Terry Production Server

## 1) Start Postgres (use your docker-compose or local service)
export POSTGRES_DSN=postgresql://user:${POSTGRES_PASSWORD:-password}@localhost:5432/automation_matrix

## 2) Install deps
python -m venv .venv && source .venv/bin/activate
pip install -r /mnt/data/requirements.prod.txt

## 3) Environment
export FRED_API_KEY=YOUR_FRED_KEY
export N8N_BASE_URL=http://localhost:5678
export N8N_API_KEY=YOUR_N8N_KEY

## 4) Launch API
python -m terry.app.main  # listens on :8000

# Health
curl http://localhost:8000/healthz

# Macro snapshot
curl -X POST http://localhost:8000/api/analysis/macro -H 'Content-Type: application/json' -d '{"series":["FEDFUNDS","CPIAUCSL"]}'
