# Run Terry Production Server

## 1) Start Postgres (use your docker-compose or local service)
export POSTGRES_DSN=postgresql://user:${POSTGRES_PASSWORD:-password}@localhost:5432/automation_matrix

## 2) Install deps
python -m venv .venv && source .venv/bin/activate
pip install -r /mnt/data/requirements.prod.txt

## 3) Environment
export FRED_API_KEY=YOUR_FRED_KEY
export N8N_BASE_URL=http://localhost:5678
export N8N_API_KEY=YOUR_N8N_KEY

## 4) Launch API
python -m terry.app.main  # listens on :8000

# Health
curl http://localhost:8000/healthz

# Macro snapshot
curl -X POST http://localhost:8000/api/analysis/macro -H 'Content-Type: application/json' -d '{"series":["FEDFUNDS","CPIAUCSL"]}'

## 5) Run Alembic migrations
export POSTGRES_DSN="postgresql://user:${POSTGRES_PASSWORD:-password}@localhost:5432/automation_matrix"
alembic -c /mnt/data/alembic.ini upgrade head

## 6) Earnings digest
curl -X POST http://localhost:8000/api/analysis/earnings -H 'Content-Type: application/json' -d '{"ticker":"AAPL"}'

## 7) Admin: refresh keys (Matrix hot-reload)
curl -X POST http://localhost:8000/api/admin/refresh-keys
curl -X POST http://localhost:8000/api/admin/reload-descriptors

## 8) Vector search (pgvector)
# Requires superuser or extension availability
alembic -c /mnt/data/alembic.ini upgrade head

# Index & search
curl -X POST http://localhost:8000/api/knowledge/index -H 'Content-Type: application/json'       -d '{"id":"doc-1","text":"This system supports a symbiotic recursive cognition loop.","metadata":{"tag":"demo"}}'

curl -X POST http://localhost:8000/api/knowledge/search -H 'Content-Type: application/json'       -d '{"query":"recursive cognition", "k": 3}'

## 9) Feedback API
curl -X POST http://localhost:8000/api/learn/feedback -H 'Content-Type: application/json'       -d '{"session_id":"s1","task":"macro snapshot","rating":4.5,"notes":"great"}'

## 10) Slack notifications
export SLACK_BOT_TOKEN=xoxb-...   # bot token
export SLACK_CHANNEL=C0123456789  # channel id or #name
curl -X POST http://localhost:8000/api/admin/slack-test -H 'Content-Type: application/json'       -d '{"text":"Terry online! 🚀"}'
