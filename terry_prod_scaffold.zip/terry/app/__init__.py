from __future__ import annotations
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from terry.common.middleware import RequestIDMiddleware, limiter
from .routes import router
from fastapi.staticfiles import StaticFiles
from terry.common.logging import logger
from terry.common.config import settings
from terry.common.scheduler import scheduler, start_scheduler

app = FastAPI(title="Terry Delmonico", version="2.2")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_headers=["*"], allow_methods=["*"])
app.add_middleware(RequestIDMiddleware)
app.include_router(router)

@app.on_event("startup")
async def _startup():
    # start background scheduler and jobs
    start_scheduler()
    logger.info(f"App started with settings: {settings.printable()}")

@app.get("/healthz")
async def healthz():
    return {"ok": True}

app.mount('/', StaticFiles(directory='terry/ui/static', html=True), name='ui')


# Prometheus metrics
from prometheus_fastapi_instrumentator import Instrumentator
Instrumentator().instrument(app).expose(app)

# SlowAPI rate-limiting
from slowapi.errors import RateLimitExceeded
from fastapi.responses import PlainTextResponse
@app.exception_handler(RateLimitExceeded)
async def ratelimit_handler(request, exc):
    return PlainTextResponse("Too Many Requests", status_code=429)
