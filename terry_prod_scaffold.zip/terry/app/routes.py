from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from terry.common.security import guardian
from terry.agents.ultimate_terry import Terry
from terry.automation.n8n_adapter import N8NClient
from terry.automation.matrix import AutomationMatrix
from terry.common.config import settings

router = APIRouter()
agent = Terry()
matrix = AutomationMatrix()
n8n = N8NClient(settings.n8n_base_url, api_key_provider=lambda: matrix.get_api_key("N8N"))

class ChatIn(BaseModel):
    message: str
    include_knowledge: bool = True
    use_persona: bool = True

@router.post("/api/chat")
async def chat(inp: ChatIn):
    await guardian.ensure_capability("chat")
    try:
        return await agent.handle_chat(inp.message, inp.include_knowledge, inp.use_persona)
    except Exception as e:
        raise HTTPException(500, detail=str(e))

class MacroIn(BaseModel):
    series: list[str] = ["FEDFUNDS","CPIAUCSL"]

@router.post("/api/analysis/macro")
async def macro(inp: MacroIn):
    data = await agent.macro_snapshot(inp.series)
    return data


class EarningsIn(BaseModel):
    ticker: str

@router.post("/api/analysis/earnings")
async def earnings(inp: EarningsIn):
    data = await agent.earnings_digest(inp.ticker)
    return data

class TaskIn(BaseModel):
    task: str

@router.post("/api/task")
async def task(inp: TaskIn):
    # Ask matrix for a plan and proceed
    plan = matrix.plan_for_task(inp.task)
    res = await agent.handle_task(inp.task)
    return {"plan": plan, "result": res}

class WorkflowCreate(BaseModel):
    name: str
    nodes: list[dict]
    connections: dict

@router.post("/api/workflows")
async def create_workflow(wf: WorkflowCreate):
    if matrix.get_api_key("N8N") is None:
        raise HTTPException(400, detail="N8N API key not configured/refreshed")
    created = await n8n.create_workflow(wf.name, wf.nodes, wf.connections)
    return created

# --- Admin endpoints ---
@router.post("/api/admin/refresh-keys")
async def refresh_keys():
    matrix.refresh_credentials()
    return {"ok": True, "services": list(matrix._credentials.keys())}

@router.post("/api/admin/reload-descriptors")
async def reload_desc():
    matrix.reload_descriptors()
    return {"ok": True, "counts": {
        "apis": len(matrix._apis),
        "mappings": len(matrix._mappings),
        "workflows": len(matrix._workflows),
    }}
