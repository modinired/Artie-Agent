from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from terry.common.security import guardian
from terry.agents.ultimate_terry import Terry
from terry.automation.n8n_adapter import N8NClient
from terry.common.config import settings

router = APIRouter()
agent = Terry()
n8n = N8NClient(settings.n8n_base_url, settings.api_keys.n8n) if settings.api_keys.n8n else None

class ChatIn(BaseModel):
    message: str
    include_knowledge: bool = True
    use_persona: bool = True

@router.post("/api/chat")
async def chat(inp: ChatIn):
    await guardian.ensure_capability("chat")
    try:
        return await agent.handle_chat(inp.message, inp.include_knowledge, inp.use_persona)
    except Exception as e:
        raise HTTPException(500, detail=str(e))

class MacroIn(BaseModel):
    series: list[str] = ["FEDFUNDS","CPIAUCSL"]

@router.post("/api/analysis/macro")
async def macro(inp: MacroIn):
    data = await agent.macro_snapshot(inp.series)
    return data

class TaskIn(BaseModel):
    task: str

@router.post("/api/task")
async def task(inp: TaskIn):
    res = await agent.handle_task(inp.task)
    return res

class WorkflowCreate(BaseModel):
    name: str
    nodes: list[dict]
    connections: dict

@router.post("/api/workflows")
async def create_workflow(wf: WorkflowCreate):
    if n8n is None:
        raise HTTPException(400, detail="N8N not configured")
    created = await n8n.create_workflow(wf.name, wf.nodes, wf.connections)
    return created
