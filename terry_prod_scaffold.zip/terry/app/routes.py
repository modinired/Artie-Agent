from __future__ import annotations
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from terry.common.security import guardian
from terry.agents.ultimate_terry import Terry
from terry.automation.n8n_adapter import N8NClient
from terry.automation.matrix import AutomationMatrix
from terry.common.config import settings
from terry.common.auth import issue_token, validate_user, require_auth, require_roles
from fastapi import Depends
from terry.common.middleware import limiter
RequireAuth = Depends(require_roles('admin'))

router = APIRouter()
agent = Terry()
matrix = AutomationMatrix()
n8n = N8NClient(settings.n8n_base_url, api_key_provider=lambda: matrix.get_api_key("N8N"))

class ChatIn(BaseModel):
    message: str
    include_knowledge: bool = True
    use_persona: bool = True

@router.post("/api/chat")
async def chat(inp: ChatIn, user=Depends(require_auth)):
    await guardian.ensure_capability("chat")
    try:
        return await agent.handle_chat(inp.message, inp.include_knowledge, inp.use_persona)
    except Exception as e:
        raise HTTPException(500, detail=str(e))

class MacroIn(BaseModel):
    series: list[str] = ["FEDFUNDS","CPIAUCSL"]

@router.post("/api/analysis/macro")
@limiter.limit("60/minute")
async def macro(inp: MacroIn, user=Depends(require_auth)):
    data = await agent.macro_snapshot(inp.series)
    return data


class EarningsIn(BaseModel):
    ticker: str

@router.post("/api/analysis/earnings")
@limiter.limit("30/minute")
async def earnings(inp: EarningsIn, user=Depends(require_auth)):
    data = await agent.earnings_digest(inp.ticker)
    return data

class TaskIn(BaseModel):
    task: str

@router.post("/api/task")
@limiter.limit("60/minute")
async def task(inp: TaskIn, user=Depends(require_auth)):
    # Ask matrix for a plan and proceed
    plan = matrix.plan_for_task(inp.task)
    res = await agent.handle_task(inp.task)
    return {"plan": plan, "result": res}

class WorkflowCreate(BaseModel):
    name: str
    nodes: list[dict]
    connections: dict

@router.post("/api/workflows")
async def create_workflow(wf: WorkflowCreate, user=Depends(require_roles('analyst','admin'))):
    if matrix.get_api_key("N8N") is None:
        raise HTTPException(400, detail="N8N API key not configured/refreshed")
    created = await n8n.create_workflow(wf.name, wf.nodes, wf.connections)
    try:
        from terry.common.notify import notify_text
        notify_text(f"Workflow created: {wf.name}")
    except Exception:
        pass
    return created

# --- Admin endpoints ---
@router.post("/api/admin/refresh-keys")
async def refresh_keys(user=RequireAuth):
    matrix.refresh_credentials()
    return {"ok": True, "services": list(matrix._credentials.keys())}

@router.post("/api/admin/reload-descriptors")
async def reload_desc(user=RequireAuth):
    matrix.reload_descriptors()
    return {"ok": True, "counts": {
        "apis": len(matrix._apis),
        "mappings": len(matrix._mappings),
        "workflows": len(matrix._workflows),
    }}


class FeedbackIn(BaseModel):
    session_id: str | None = None
    task: str | None = None
    rating: float
    notes: str | None = None

@router.post("/api/learn/feedback")
async def feedback(inp: FeedbackIn):
    # insert into interaction_feedback + audit_log
    import psycopg2
    from terry.common.config import settings
from terry.common.auth import issue_token, validate_user, require_auth, require_roles
from fastapi import Depends
from terry.common.middleware import limiter
RequireAuth = Depends(require_roles('admin'))
    conn = psycopg2.connect(settings.postgres_dsn)
    try:
        with conn, conn.cursor() as cur:
            cur.execute("INSERT INTO interaction_feedback(session_id, task, rating, notes) VALUES(%s,%s,%s,%s)",
                        (inp.session_id, inp.task, inp.rating, inp.notes))
            cur.execute("INSERT INTO audit_log(actor, action, details) VALUES(%s,%s,%s)",
                        ("user", "feedback", psycopg2.extras.Json({"session_id": inp.session_id, "task": inp.task, "rating": inp.rating})))
    finally:
        conn.close()
    return {"ok": True}


class SlackTestIn(BaseModel):
    text: str
    channel: str | None = None

@router.post("/api/admin/slack-test")
async def slack_test(inp: SlackTestIn, user=RequireAuth):
    from terry.common.notify import notify_text
    resp = notify_text(inp.text, inp.channel)
    return resp


class IndexIn(BaseModel):
    id: str
    text: str
    metadata: dict | None = None

@router.post("/api/knowledge/index")
async def rag_index(inp: IndexIn, user=Depends(require_roles('analyst','admin'))):
    from terry.knowledge.knowledge_brain import index_document
    return await index_document(inp.id, inp.text, inp.metadata or {})

class SearchIn(BaseModel):
    query: str
    k: int = 5

@router.post("/api/knowledge/search")
async def rag_search(inp: SearchIn, user=Depends(require_auth)):
    from terry.knowledge.knowledge_brain import search_knowledge
    return await search_knowledge(inp.query, inp.k)


class IndexInFB(BaseModel):
    id: str
    text: str
    metadata: dict | None = None

@router.post("/api/knowledge/index_fallback")
@limiter.limit("30/minute")
async def rag_index_fb(inp: IndexInFB, user=Depends(require_roles('analyst','admin'))):
    from terry.knowledge.knowledge_brain import index_document_fallback
    return await index_document_fallback(inp.id, inp.text, inp.metadata or {})

class SearchInFB(BaseModel):
    query: str
    k: int = 5

@router.post("/api/knowledge/search_fallback")
@limiter.limit("60/minute")
async def rag_search_fb(inp: SearchInFB, user=Depends(require_auth)):
    from terry.knowledge.knowledge_brain import search_knowledge_fallback
    return await search_knowledge_fallback(inp.query, inp.k)


class LoginIn(BaseModel):
    username: str

@router.post("/api/auth/login")
async def login(inp: LoginIn):
    user = validate_user(inp.username)
    if not user:
        # deny unknown
        raise HTTPException(401, detail="Unknown user")
    token = issue_token(inp.username, user.get("roles", []))
    return {"access_token": token, "token_type": "bearer", "roles": user.get("roles", [])}
