from __future__ import annotations
import json
from typing import Optional, List, Dict, Any
import psycopg2
from psycopg2.pool import SimpleConnectionPool
from terry.common.config import settings
from sentence_transformers import SentenceTransformer

_DIM = 384  # all-MiniLM-L6-v2
_model: SentenceTransformer | None = None
_pool: SimpleConnectionPool | None = None

def _pool() -> SimpleConnectionPool:
    global _pool
    if _pool is None:
        _pool = SimpleConnectionPool(1, 10, dsn=settings.postgres_dsn)
    return _pool

def _model_inst() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return _model

def ensure_extension_and_table() -> None:
    conn = _pool().getconn()
    try:
        with conn, conn.cursor() as cur:
            cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            cur.execute("""            CREATE TABLE IF NOT EXISTS kb_documents(
                id TEXT PRIMARY KEY,
                text TEXT NOT NULL,
                metadata JSONB,
                embedding vector(%s)
            );""", (_DIM,))
            cur.execute("""                CREATE INDEX IF NOT EXISTS kb_documents_embedding_idx 
                ON kb_documents USING ivfflat (embedding vector_l2_ops) WITH (lists = 100);
            """)
    finally:
        _pool().putconn(conn)

def embed(texts: List[str]) -> List[List[float]]:
    m = _model_inst()
    vecs = m.encode(texts, normalize_embeddings=True).tolist()
    return vecs

def upsert_document(doc_id: str, text: str, metadata: Dict[str, Any] | None = None) -> None:
    ensure_extension_and_table()
    vec = embed([text])[0]
    conn = _pool().getconn()
    try:
        with conn, conn.cursor() as cur:
            cur.execute(                "INSERT INTO kb_documents(id,text,metadata,embedding) VALUES(%s,%s,%s,%s) "
                "ON CONFLICT (id) DO UPDATE SET text=excluded.text, metadata=excluded.metadata, embedding=excluded.embedding",
                (doc_id, text, json.dumps(metadata or {}), vec)
            )
    finally:
        _pool().putconn(conn)

def search(query: str, k: int = 5) -> List[Dict[str, Any]]:
    ensure_extension_and_table()
    qv = embed([query])[0]
    conn = _pool().getconn()
    try:
        with conn, conn.cursor() as cur:
            cur.execute(                "SELECT id, text, metadata FROM kb_documents ORDER BY embedding <-> %s LIMIT %s",
                (qv, k)
            )
            rows = cur.fetchall()
            return [{"id": r[0], "text": r[1], "metadata": r[2]} for r in rows]
    finally:
        _pool().putconn(conn)
