from __future__ import annotations
import psycopg2, json
from psycopg2.pool import SimpleConnectionPool
from terry.common.config import settings

_pool: SimpleConnectionPool | None = None

def pool() -> SimpleConnectionPool:
    global _pool
    if _pool is None:
        _pool = SimpleConnectionPool(1, 10, dsn=settings.postgres_dsn)
    return _pool

def persist(category: str, key: str, payload: dict) -> None:
    conn = pool().getconn()
    try:
        with conn, conn.cursor() as cur:
            cur.execute("""
CREATE TABLE IF NOT EXISTS knowledge_updates (
  id SERIAL PRIMARY KEY,
  ts TIMESTAMP DEFAULT NOW(),
  category TEXT NOT NULL,
  key TEXT NOT NULL,
  payload JSONB NOT NULL
)
""")
            cur.execute("INSERT INTO knowledge_updates(category,key,payload) VALUES(%s,%s,%s)", (category, key, json.dumps(payload)))
    finally:
        pool().putconn(conn)
