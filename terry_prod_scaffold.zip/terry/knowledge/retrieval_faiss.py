from __future__ import annotations
import faiss, os, json
from typing import List, Dict, Any, Tuple
from sentence_transformers import SentenceTransformer

_DIM = 384
_model: SentenceTransformer | None = None

def _model_inst() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    return _model

class FaissStore:
    def __init__(self, path: str = "/mnt/data/faiss.index", meta_path: str = "/mnt/data/faiss_meta.json"):
        self.path = path
        self.meta_path = meta_path
        self.index = None
        self.meta: Dict[int, Dict[str, Any]] = {}
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            self.index = faiss.read_index(self.path)
        else:
            self.index = faiss.index_factory(_DIM, "IVF100,Flat", faiss.METRIC_L2)
            self.index.nprobe = 10
            quantizer = faiss.IndexFlatL2(_DIM)
            self.index = faiss.IndexIVFFlat(quantizer, _DIM, 100, faiss.METRIC_L2)
            # needs training before add
        if os.path.exists(self.meta_path):
            with open(self.meta_path) as f:
                self.meta = {int(k): v for k, v in json.load(f).items()}

    def _save(self):
        faiss.write_index(self.index, self.path)
        with open(self.meta_path, "w") as f:
            json.dump({int(k): v for k, v in self.meta.items()}, f)

    def _embed(self, texts: List[str]):
        m = _model_inst()
        return m.encode(texts, normalize_embeddings=True)

    def upsert_many(self, docs: List[Tuple[str, str, Dict[str, Any]]]):
        # docs: [(id, text, metadata)]
        vecs = self._embed([t for _, t, _ in docs])
        if not self.index.is_trained:
            self.index.train(vecs.astype("float32"))
        start_id = max(self.meta.keys()) + 1 if self.meta else 0
        ids = list(range(start_id, start_id + len(docs)))
        self.index.add_with_ids(vecs.astype("float32"), (faiss.numpy.array(ids, dtype='int64')))
        for i, (doc_id, text, meta) in enumerate(docs):
            self.meta[ids[i]] = {"id": doc_id, "text": text, "metadata": meta}
        self._save()

    def search(self, query: str, k: int = 5):
        qv = self._embed([query])
        if not self.index.is_trained:
            return []
        D, I = self.index.search(qv.astype("float32"), k)
        out = []
        for i in I[0]:
            if i == -1: 
                continue
            out.append(self.meta.get(int(i), {}))
        return out
