from __future__ import annotations
import aiohttp
from terry.common.config import APIKeys
from terry.knowledge.store import persist

class KnowledgeBrain:
    def __init__(self, keys: APIKeys) -> None:
        self.keys = keys

    async def ping_fred(self) -> dict:
        # attempt a harmless request to verify connectivity
        url = "https://api.stlouisfed.org/fred/category"
        params = {"category_id": 0, "api_key": self.keys.fred or "", "file_type": "json"}
        async with aiohttp.ClientSession() as s:
            async with s.get(url, params=params) as r:
                ok = r.status == 200
                return {"ok": ok, "status": r.status}

    async def fetch_fred_series(self, series_id: str) -> dict:
        url = "https://api.stlouisfed.org/fred/series/observations"
        params = {"series_id": series_id, "api_key": self.keys.fred or "", "file_type": "json"}
        async with aiohttp.ClientSession() as s:
            async with s.get(url, params=params, timeout=aiohttp.ClientTimeout(total=30)) as r:
                r.raise_for_status()
                j = await r.json()
                persist("financial", series_id, j)
                return j

from __future__ import annotations
from terry.knowledge.adapters import sec, polygon

async def earnings_digest(ticker: str) -> dict:
    # Resolve CIK via SEC, pull submissions; pull latest close + financials via Polygon (if key present)
    cik = await sec.cik_for_ticker(ticker)
    sec_data = await sec.latest_submissions(cik) if cik else {}
    poly_info, poly_close, poly_fin = {}, {}, {}
    try:
        poly_info = await polygon.company_info(ticker)
        poly_close = await polygon.previous_close(ticker)
        poly_fin = await polygon.financials(ticker, limit=1)
    except Exception as e:
        poly_info = {"error": str(e)}
    return {
        "ticker": ticker.upper(),
        "cik": cik,
        "sec": sec_data,
        "polygon": {"info": poly_info, "previous_close": poly_close, "financials": poly_fin}
    }


# --- RAG (pgvector) convenience ---
async def index_document(doc_id: str, text: str, metadata: dict | None = None) -> dict:
    from terry.knowledge.retrieval_pgvector import upsert_document
    upsert_document(doc_id, text, metadata or {})
    return {"ok": True}

async def search_knowledge(query: str, k: int = 5) -> dict:
    from terry.knowledge.retrieval_pgvector import search, ensure_extension_and_table
    ensure_extension_and_table()
    hits = search(query, k)
    return {"hits": hits}
