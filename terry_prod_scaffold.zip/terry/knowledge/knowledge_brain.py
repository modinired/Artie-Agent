from __future__ import annotations
import aiohttp
from terry.common.config import APIKeys
from terry.knowledge.store import persist

class KnowledgeBrain:
    def __init__(self, keys: APIKeys) -> None:
        self.keys = keys

    async def ping_fred(self) -> dict:
        # attempt a harmless request to verify connectivity
        url = "https://api.stlouisfed.org/fred/category"
        params = {"category_id": 0, "api_key": self.keys.fred or "", "file_type": "json"}
        async with aiohttp.ClientSession() as s:
            async with s.get(url, params=params) as r:
                ok = r.status == 200
                return {"ok": ok, "status": r.status}

    async def fetch_fred_series(self, series_id: str) -> dict:
        url = "https://api.stlouisfed.org/fred/series/observations"
        params = {"series_id": series_id, "api_key": self.keys.fred or "", "file_type": "json"}
        async with aiohttp.ClientSession() as s:
            async with s.get(url, params=params, timeout=aiohttp.ClientTimeout(total=30)) as r:
                r.raise_for_status()
                j = await r.json()
                persist("financial", series_id, j)
                return j
