from __future__ import annotations
import aiohttp, os

SEC_BASE = "https://data.sec.gov"

def _headers():
    ua = os.getenv("SEC_USER_AGENT", "TerryAgent/1.0 modines@example.com")
    return {"User-Agent": ua, "Accept": "application/json"}

async def latest_submissions(cik_or_ticker: str) -> dict:
    # If ticker provided, SEC supports mapping via submissions API only by CIK; we try ticker file
    # Use the submissions endpoint which works with CIK (10-digit, zero-padded). If ticker, try company-tickers.json
    async with aiohttp.ClientSession(headers=_headers()) as s:
        # Pull mapping
        async with s.get(f"{SEC_BASE}/api/xbrl/companyfacts/CIK{cik_or_ticker}.json") as r1:
            if r1.status == 200:
                facts = await r1.json()
            else:
                facts = {}
        async with s.get(f"{SEC_BASE}/submissions/CIK{cik_or_ticker}.json") as r2:
            r2.raise_for_status()
            subs = await r2.json()
        return {"facts": facts, "submissions": subs}

async def company_tickers() -> list[dict]:
    async with aiohttp.ClientSession(headers=_headers()) as s:
        async with s.get(f"{SEC_BASE}/api/xbrl/company_tickers.json") as r:
            r.raise_for_status()
            return await r.json()

async def cik_for_ticker(ticker: str) -> str | None:
    data = await company_tickers()
    # data is list indexed by integers with keys 'cik_str','ticker'
    for row in data:
        if row.get("ticker","").upper() == ticker.upper():
            return str(row.get("cik_str")).zfill(10)
    return None
