from __future__ import annotations
import aiohttp, os

POLY_BASE = "https://api.polygon.io"

def _key() -> str | None:
    return os.getenv("POLYGON_API_KEY")

async def previous_close(ticker: str) -> dict:
    key = _key()
    if not key:
        raise RuntimeError("POLYGON_API_KEY not set")
    url = f"{POLY_BASE}/v2/aggs/ticker/{ticker}/prev"
    async with aiohttp.ClientSession() as s:
        async with s.get(url, params={"adjusted":"true","apiKey":key}) as r:
            r.raise_for_status()
            return await r.json()

async def company_info(ticker: str) -> dict:
    key = _key()
    if not key:
        raise RuntimeError("POLYGON_API_KEY not set")
    url = f"{POLY_BASE}/v3/reference/tickers/{ticker}"
    async with aiohttp.ClientSession() as s:
        async with s.get(url, params={"apiKey":key}) as r:
            r.raise_for_status()
            return await r.json()

async def financials(ticker: str, limit: int = 1) -> dict:
    key = _key()
    if not key:
        raise RuntimeError("POLYGON_API_KEY not set")
    url = f"{POLY_BASE}/vX/reference/financials"
    async with aiohttp.ClientSession() as s:
        async with s.get(url, params={"ticker":ticker,"limit":limit,"apiKey":key}) as r:
            r.raise_for_status()
            return await r.json()
