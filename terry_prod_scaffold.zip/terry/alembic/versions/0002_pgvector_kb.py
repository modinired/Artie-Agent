from alembic import op
import sqlalchemy as sa

revision = '0002_pgvector_kb'
down_revision = '0001_init_learning_audit'
branch_labels = None
depends_on = None

def upgrade():
    op.execute("CREATE EXTENSION IF NOT EXISTS vector;")
    op.execute("""        CREATE TABLE IF NOT EXISTS kb_documents(
            id TEXT PRIMARY KEY,
            text TEXT NOT NULL,
            metadata JSONB,
            embedding vector(384)
        );
    """)
    op.execute("""        CREATE INDEX IF NOT EXISTS kb_documents_embedding_idx 
        ON kb_documents USING ivfflat (embedding vector_l2_ops) WITH (lists = 100);
    """)

def downgrade():
    op.execute("DROP TABLE IF EXISTS kb_documents;")
