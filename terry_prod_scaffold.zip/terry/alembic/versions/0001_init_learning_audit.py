from alembic import op
import sqlalchemy as sa

revision = '0001_init_learning_audit'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.execute("""    CREATE TABLE IF NOT EXISTS audit_log(
        id SERIAL PRIMARY KEY,
        ts TIMESTAMP DEFAULT NOW(),
        actor TEXT,
        action TEXT,
        details JSONB
    );
    CREATE TABLE IF NOT EXISTS interaction_feedback(
        id SERIAL PRIMARY KEY,
        ts TIMESTAMP DEFAULT NOW(),
        session_id TEXT,
        task TEXT,
        rating NUMERIC,
        notes TEXT
    );
    CREATE TABLE IF NOT EXISTS automation_runs(
        id SERIAL PRIMARY KEY,
        ts TIMESTAMP DEFAULT NOW(),
        workflow_name TEXT,
        status TEXT,
        payload JSONB,
        result JSONB
    );
    """)


def downgrade():
    op.execute("DROP TABLE IF EXISTS automation_runs;")
    op.execute("DROP TABLE IF EXISTS interaction_feedback;")
    op.execute("DROP TABLE IF EXISTS audit_log;")
